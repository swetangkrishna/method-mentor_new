# Pedagogical RL Experiment — M1 + RL Signal

## What this is

A complete implementation of **Method 1 (M1)** — human-authored pedagogical skill library —
augmented with an **RL reward signal**. Two Claude/LLM instances run in a loop:

- **Agent** (teacher/tutor): selects from 16 pedagogical skills each turn
- **Persona** (simulated learner): responds authentically, tracks understanding, fills survey

All sessions, turns, skill uses, surveys, and rewards are saved to **SQLite** for analysis.

---

## Project structure

```
pedagogy_rl/
├── skills_M1/                      ← 16 SKILL.md files (flat, no nesting)
│   ├── align-outcomes-activities-assessment_SKILL.md
│   ├── assign-stretch-tasks_SKILL.md
│   ├── challenge-assumptions_SKILL.md
│   ├── confirm-competence_SKILL.md
│   ├── design-learning-experience_SKILL.md
│   ├── diagnose-zpd_SKILL.md
│   ├── encourage-metacognition_SKILL.md
│   ├── facilitate-discussion_SKILL.md
│   ├── identify-misconceptions_SKILL.md
│   ├── probe-intended-decisions_SKILL.md
│   ├── provide-emotional-support_SKILL.md
│   ├── provide-formative-feedback_SKILL.md
│   ├── reflect-on-pedagogy_SKILL.md
│   ├── scaffold-and-release_SKILL.md
│   ├── set-learning-objectives_SKILL.md
│   └── transform-content_SKILL.md
├── db/
│   └── pedagogy_rl.db              ← SQLite (auto-created on first run)
├── results/                        ← JSON result files + analysis report
├── model_config.py                 ← ⬅ CHANGE BACKEND HERE (one line)
├── api_client.py                   ← HuggingFace / Ollama / Anthropic client
├── skill_loader.py                 ← Reads skills_M1/ flat directory
├── database.py                     ← All SQLite operations
├── scenarios.py                    ← Scenario + survey definitions
├── agent.py                        ← Pedagogical agent (skill selection)
├── persona.py                      ← Simulated learner persona
├── reward.py                       ← Composite reward calculator
├── run_experiment.py               ← Automated LLM-persona batch runner
├── human_validation_server.py      ← Flask web UI (human plays learner)
└── analyse_results.py              ← RL analysis report from DB
```

---

## Setup — 3 minutes

### 1. Install dependencies

```bash
pip install flask
# That's all. Everything else uses Python stdlib.
```

### 2. Choose your backend — edit ONE line in model_config.py

**Option A — HuggingFace Inference API (free, no GPU, recommended to start)**
```python
BACKEND  = "huggingface"
HF_MODEL = "Qwen/Qwen2.5-14B-Instruct"
```
```bash
export HF_TOKEN=hf_...   # get free at https://huggingface.co/settings/tokens
```

**Option B — Ollama (local, Apple Silicon, no API key)**
```python
BACKEND      = "ollama"
OLLAMA_MODEL = "qwen2.5:32b"   # or 14b/7b depending on RAM
```
```bash
# Install: https://ollama.com
ollama serve
ollama pull qwen2.5:32b
```

**Option C — Anthropic (paid, highest quality)**
```python
BACKEND = "anthropic"
```
```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

---

## Running

### Automated runs (LLM persona, batch)

```bash
# Single run
python run_experiment.py --scenario S01

# 5 runs for RL averaging
python run_experiment.py --scenario S01 --runs 5

# All 3 scenarios, 3 runs each
python run_experiment.py --scenario all --runs 3
```

### Human validation (you play the learner, web UI)

```bash
python human_validation_server.py
# Open http://localhost:5000
```

### Analyse results

```bash
python analyse_results.py
# Reads DB → saves results/analysis_report.md
```

---

## Scenarios

| ID | Topic | Skill target | Role | Max turns |
|----|-------|-------------|------|-----------|
| S01 | Python recursion | scaffold-and-release | Tutor | 12 |
| S02 | Lesson plan alignment | align-outcomes-activities-assessment | Educator | 10 |
| S03 | Python list comprehensions | diagnose-zpd | Tutor | 10 |

---

## Database schema

**`sessions`** — one row per episode (automated or human)
**`turns`** — one row per agent/learner/human turn
**`skill_uses`** — one row per skill invocation, linked to turn
**`survey_responses`** — one row per survey question answer
**`rewards`** — full reward breakdown per completed session

Inspect the DB at any time:

```bash
sqlite3 db/pedagogy_rl.db
.tables
SELECT skill_name, COUNT(*) as uses, AVG(r.total_reward) as avg_reward
FROM skill_uses su JOIN rewards r ON r.session_id = su.session_id
GROUP BY skill_name ORDER BY avg_reward DESC;
```

---

## Reward function

```
reward = 0.50 × task_solved_score    (1.0 if solved, 0.8 if persona confirms, 0.5 partial)
       + 0.30 × survey_normalised    (mean Q1–Q5 mapped 1-5 → 0-1)
       + 0.20 × efficiency_score     (1 − turns_used / max_turns)
```

| Band | Range |
|------|-------|
| EXCELLENT | ≥ 0.85 |
| GOOD | ≥ 0.70 |
| ACCEPTABLE | ≥ 0.50 |
| POOR | ≥ 0.30 |
| FAILED | < 0.30 |

---

## RL interpretation

After 5–10 runs per scenario, `analyse_results.py` gives you:

- **Skill frequency by reward band** → which skills appear more in high-reward episodes
- **Best skill per turn position** → the derived pedagogical policy (e.g. "turn 1 → diagnose-zpd")
- **Human vs LLM comparison** → whether the simulated persona is too easy or too agreeable
- **M2 connection** → high-reward sequences = preferred GRPO demonstrations
- **M5 connection** → co-occurring adjacent skills = composite synthesis candidates

---

## Adding skills

Drop a new `{skill-name}_SKILL.md` file into `skills_M1/`.
The loader auto-discovers all `*_SKILL.md` files — no code changes needed.

## Adding scenarios

Add an entry to the `SCENARIOS` dict in `scenarios.py`.
