"""
run_experiment.py — Automated RL experiment runner (LLM persona).

Saves every session, turn, skill use, survey, and reward to SQLite + JSON.

Usage:
    python run_experiment.py --scenario S01 [--runs 5] [--quiet]
    python run_experiment.py --scenario all --runs 3
"""

import argparse
import json
import sys
import time
import uuid
from datetime import datetime
from pathlib import Path

from model_config import print_config, get_config
from api_client import check_ollama_running, check_hf_model, _get_hf_token
from skill_loader import load_all_skills
from scenarios import SCENARIOS, SURVEY_QUESTIONS
from agent import agent_turn
from persona import persona_respond, persona_fill_survey, persona_task_check
from reward import calculate_reward, skill_sequence_stats
from database import Database

RESULTS_DIR = Path(__file__).parent / "results"
RESULTS_DIR.mkdir(exist_ok=True)


def run_episode(scenario: Dict, skills: Dict, db: Database,
                verbose: bool = True) -> Dict:
    sc  = scenario
    pid = sc["id"]
    run_id = f"{pid}_auto_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"

    cfg = get_config()
    session_id = db.create_session(
        session_id    = run_id,
        scenario_id   = pid,
        scenario_topic= sc["topic"],
        mode          = "automated",
        backend       = cfg["backend"],
        model         = cfg["model"],
        max_turns     = sc["max_turns"],
        persona_name  = sc["learner_persona"]["name"],
    )

    if verbose:
        print(f"\n{'='*60}\nEpisode: {run_id}\nScenario: {pid} — {sc['topic']}\n{'='*60}")

    history: list        = []
    skill_seq: list      = []
    understanding: list  = []
    task_solved          = False
    final_turn           = 0

    for turn in range(1, sc["max_turns"] + 1):
        final_turn = turn

        # ── Agent ────────────────────────────────────────────────────────────
        ar = agent_turn(skills, sc, history, skill_seq, turn)
        skill_seq.append(ar["skill_name"])
        history.append({"role": "assistant", "content": ar["response"]})

        t_id = db.log_turn(run_id, turn, "agent", ar["response"],
                           agent_declared_solved=ar["task_solved"])
        db.log_skill_use(run_id, t_id, turn, ar["skill_name"], ar["reasoning"])

        if verbose:
            print(f"\n[T{turn}] AGENT  skill={ar['skill_name']}")
            print(f"  {ar['response'][:250]}{'…' if len(ar['response'])>250 else ''}")

        if ar["task_solved"]:
            task_solved = True; break

        # ── Persona ──────────────────────────────────────────────────────────
        pr = persona_respond(sc, history)
        understanding.append(pr["understanding_level"])
        history.append({"role": "user", "content": pr["response"]})

        db.log_turn(run_id, turn, "persona", pr["response"],
                    understanding_level=pr["understanding_level"],
                    learner_ready=pr["learner_ready"])

        if verbose:
            print(f"[T{turn}] PERSONA  understanding={pr['understanding_level']}/10")
            print(f"  {pr['response'][:200]}{'…' if len(pr['response'])>200 else ''}")

        if pr["learner_ready"]:
            task_solved = True; break

    # ── Task check ───────────────────────────────────────────────────────────
    task_check = persona_task_check(sc, history)
    if not task_solved and task_check.get("solved"):
        task_solved = True

    # ── Survey ───────────────────────────────────────────────────────────────
    survey_result = persona_fill_survey(sc, history, SURVEY_QUESTIONS, task_solved, final_turn)
    db.log_survey(run_id, survey_result["survey"], respondent_type="persona")

    # ── Reward ───────────────────────────────────────────────────────────────
    reward = calculate_reward(task_solved, survey_result["survey"],
                              final_turn, sc["max_turns"], task_check)
    db.log_reward(run_id, reward)
    db.complete_session(run_id, task_solved, final_turn)

    if verbose:
        print(f"\n{'─'*40}")
        print(f"RESULT: solved={task_solved}  turns={final_turn}/{sc['max_turns']}")
        print(f"REWARD: {reward['reward']} ({reward['reward_band']})")
        print(f"SKILLS: {' → '.join(skill_seq)}")

    # Save JSON result file
    result = {
        "run_id": run_id, "scenario_id": pid, "topic": sc["topic"],
        "mode": "automated", "task_solved": task_solved,
        "total_turns": final_turn, "max_turns": sc["max_turns"],
        "skill_sequence": skill_seq,
        "skill_stats": skill_sequence_stats(skill_seq),
        "understanding_progression": understanding,
        "reward": reward, "survey": survey_result["survey"],
        "task_check": task_check,
        "model": cfg["model"], "backend": cfg["backend"],
    }
    (RESULTS_DIR / f"{run_id}.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False))

    return result


def _health_check():
    print_config(); print()
    cfg = get_config()
    b   = cfg["backend"]
    if b == "huggingface":
        try:
            tok = _get_hf_token(cfg)
            st  = check_hf_model(cfg["model"], tok)
            if not st["available"]:
                print(f"[ERROR] {st['error']}"); sys.exit(1)
            msg = "loaded" if st["loaded"] else "cold start — first call will be slow"
            print(f"[ok] HF model '{cfg['model']}': {msg}\n")
        except RuntimeError as e:
            print(f"[ERROR] {e}"); sys.exit(1)
    elif b == "ollama":
        st = check_ollama_running()
        if not st["running"]:
            print(f"[ERROR] Ollama not running.\n  Fix: ollama serve"); sys.exit(1)
        m = cfg["model"]
        if not any(m in x for x in st["models"]):
            print(f"[WARN] '{m}' not pulled. Run: ollama pull {m}")
        else:
            print(f"[ok] Ollama — '{m}' ready\n")
    elif b == "anthropic":
        import os
        if not os.environ.get("ANTHROPIC_API_KEY"):
            print("[ERROR] ANTHROPIC_API_KEY not set."); sys.exit(1)
        print("[ok] Anthropic key found\n")


SCENARIO_ID_MAP = {
    "S01": "S01_recursion_confused_beginner",
    "S02": "S02_lesson_plan_alignment",
    "S03": "S03_list_comprehensions",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", default="S01",
                        help="S01 | S02 | S03 | all")
    parser.add_argument("--runs",     type=int, default=1)
    parser.add_argument("--quiet",    action="store_true")
    args = parser.parse_args()

    _health_check()

    skills = load_all_skills()
    db     = Database()

    keys = (list(SCENARIO_ID_MAP.values()) if args.scenario == "all"
            else [SCENARIO_ID_MAP.get(args.scenario, args.scenario)])

    all_results = []
    for key in keys:
        if key not in SCENARIOS:
            print(f"Unknown scenario key: {key}"); continue
        sc = SCENARIOS[key]
        for i in range(1, args.runs + 1):
            r = run_episode(sc, skills, db, verbose=not args.quiet)
            all_results.append(r)
            if args.runs > 1 and i < args.runs:
                time.sleep(2)

    db.close()

    if len(all_results) > 1:
        print(f"\n{'='*60}\nSUMMARY ({len(all_results)} runs)")
        for r in all_results:
            print(f"  {r['run_id']}  solved={r['task_solved']}  "
                  f"turns={r['total_turns']}  reward={r['reward']['reward']}  "
                  f"({r['reward']['reward_band']})")
        rewards = [r["reward"]["reward"] for r in all_results]
        print(f"  Mean reward: {sum(rewards)/len(rewards):.3f}")


if __name__ == "__main__":
    main()
