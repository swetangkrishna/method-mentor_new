"""
api_client.py — Multi-backend LLM client (HuggingFace / Ollama / Anthropic)
No external pip packages needed beyond flask for the server.
All HTTP done with stdlib urllib.
"""

import json
import os
import time
import urllib.request
import urllib.error
from typing import List, Dict

from model_config import get_config


# ── HuggingFace ───────────────────────────────────────────────────────────────

def _get_hf_token(cfg: dict) -> str:
    token = cfg.get("hf_token") or os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN", "")
    if not token:
        raise RuntimeError(
            "HuggingFace token not set.\n"
            "  Get a free token: https://huggingface.co/settings/tokens\n"
            "  Then run: export HF_TOKEN=hf_..."
        )
    return token


def _call_hf(messages: List[Dict], system: str, max_tokens: int,
             temperature: float, cfg: dict) -> str:
    token   = _get_hf_token(cfg)
    model   = cfg["model"]
    timeout = cfg.get("timeout", 120)
    retries = cfg.get("hf_max_retries", 3)
    delay   = cfg.get("hf_retry_delay", 25)
    temp    = max(0.01, min(float(temperature), 1.0))

    payload = {
        "model": model,
        "messages": _with_system(messages, system),
        "max_tokens": max_tokens,
        "temperature": temp,
        "stream": False,
    }
    data    = json.dumps(payload).encode()
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    url     = "https://api-inference.huggingface.co/v1/chat/completions"

    for attempt in range(1, retries + 1):
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = json.loads(resp.read().decode())
                if "choices" in body:
                    return body["choices"][0]["message"]["content"].strip()
                if isinstance(body, list) and body:
                    return str(body[0].get("generated_text", body[0])).strip()
                raise RuntimeError(f"Unexpected HF response: {body}")

        except urllib.error.HTTPError as e:
            code = e.code
            err  = e.read().decode("utf-8", errors="replace")
            if code == 503:
                try:    wait = min(float(json.loads(err).get("estimated_time", delay)), 60)
                except: wait = delay
                if attempt < retries:
                    print(f"  [HF] Model loading — waiting {wait:.0f}s (attempt {attempt}/{retries})...")
                    time.sleep(wait); continue
                raise RuntimeError(f"Model '{model}' still loading after {retries} retries. Try again shortly.")
            elif code == 401:
                raise RuntimeError("HF token invalid. Get a new one: https://huggingface.co/settings/tokens")
            elif code == 403:
                raise RuntimeError(f"Access denied to '{model}'. Accept its license at https://huggingface.co/{model}")
            elif code == 429:
                if attempt < retries:
                    print(f"  [HF] Rate limited — waiting 60s (attempt {attempt}/{retries})...")
                    time.sleep(60); continue
                raise RuntimeError("HF rate limit. Upgrade to HF PRO ($9/mo) or switch BACKEND='ollama'.")
            elif code == 422:
                raise RuntimeError(f"HF rejected request (422). Try a different HF_MODEL.\nDetail: {err[:200]}")
            else:
                raise RuntimeError(f"HF API error {code}: {err[:200]}")
        except urllib.error.URLError as e:
            raise RuntimeError(f"Network error: {e.reason}")

    raise RuntimeError("Max retries exceeded.")


def check_hf_model(model: str, token: str) -> dict:
    url = f"https://api-inference.huggingface.co/models/{model}"
    req = urllib.request.Request(
        url,
        data=json.dumps({"inputs": "test"}).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10): pass
        return {"available": True, "loaded": True, "error": None}
    except urllib.error.HTTPError as e:
        if e.code == 503: return {"available": True,  "loaded": False, "error": "Cold start (loading)"}
        if e.code == 403: return {"available": False, "loaded": False, "error": "Accept license on HF"}
        if e.code == 404: return {"available": False, "loaded": False, "error": "Model not found"}
        return {"available": True, "loaded": True, "error": None}
    except Exception as e:
        return {"available": False, "loaded": False, "error": str(e)}


# ── Ollama ────────────────────────────────────────────────────────────────────

def _call_ollama(messages: List[Dict], system: str, max_tokens: int,
                 temperature: float, cfg: dict) -> str:
    host    = cfg["ollama_host"].rstrip("/")
    payload = {
        "model": cfg["model"],
        "messages": _with_system(messages, system),
        "stream": False,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
            "num_ctx": cfg.get("context_length", 8192),
        },
    }
    req = urllib.request.Request(
        f"{host}/api/chat",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=cfg.get("timeout", 180)) as resp:
            return json.loads(resp.read().decode())["message"]["content"]
    except urllib.error.URLError as e:
        raise RuntimeError(f"Ollama unreachable at {host}.\nRun: ollama serve\nError: {e.reason}")


def check_ollama_running() -> dict:
    cfg  = get_config()
    host = cfg.get("ollama_host", "http://localhost:11434").rstrip("/")
    try:
        with urllib.request.urlopen(f"{host}/api/tags", timeout=5) as resp:
            body   = json.loads(resp.read().decode())
            models = [m["name"] for m in body.get("models", [])]
            return {"running": True, "models": models, "error": None}
    except Exception as e:
        return {"running": False, "models": [], "error": str(e)}


# ── Anthropic ─────────────────────────────────────────────────────────────────

def _call_anthropic(messages: List[Dict], system: str, max_tokens: int,
                    temperature: float) -> str:
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        raise RuntimeError("ANTHROPIC_API_KEY not set.")
    payload = {
        "model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-20250514"),
        "max_tokens": max_tokens, "messages": messages, "temperature": temperature,
    }
    if system:
        payload["system"] = system
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "x-api-key": key,
                 "anthropic-version": "2023-06-01"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode())["content"][0]["text"]
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"Anthropic error {e.code}: {e.read().decode()}")


# ── Shared ────────────────────────────────────────────────────────────────────

def _with_system(messages: List[Dict], system: str) -> List[Dict]:
    if not system:
        return list(messages)
    return [{"role": "system", "content": system}] + list(messages)


# ── Public interface ──────────────────────────────────────────────────────────

def call_llm(messages: List[Dict], system: str = "", max_tokens: int = 1024,
             temperature: float = 0.7, role: str = "default") -> str:
    """Universal LLM call. Switches backend transparently via model_config.py."""
    cfg = get_config(role)
    b   = cfg["backend"]
    if   b == "huggingface": return _call_hf(messages, system, max_tokens, temperature, cfg)
    elif b == "ollama":       return _call_ollama(messages, system, max_tokens, temperature, cfg)
    elif b == "anthropic":    return _call_anthropic(messages, system, max_tokens, temperature)
    else: raise ValueError(f"Unknown backend '{b}'. Set BACKEND in model_config.py.")


def call_llm_precise(messages: List[Dict], system: str = "",
                     max_tokens: int = 1024, role: str = "scorer") -> str:
    """Low-temperature call for structured outputs (JSON, reward scoring)."""
    return call_llm(messages, system=system, max_tokens=max_tokens,
                    temperature=0.05, role=role)


# backwards-compat aliases used in legacy files
call_claude          = call_llm
call_claude_low_temp = call_llm_precise


# ── Smoke test ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    from model_config import print_config
    print_config(); print()
    cfg = get_config()
    if cfg["backend"] == "huggingface":
        tok = _get_hf_token(cfg)
        st  = check_hf_model(cfg["model"], tok)
        print(f"Model status: {st}")
    elif cfg["backend"] == "ollama":
        st = check_ollama_running()
        print(f"Ollama: {st}")
    print("\nSending test message...")
    t0   = time.time()
    resp = call_llm([{"role": "user", "content": "Reply with exactly: BACKEND OK"}],
                    temperature=0.0, max_tokens=20)
    print(f"Response ({time.time()-t0:.1f}s): {resp.strip()}")
